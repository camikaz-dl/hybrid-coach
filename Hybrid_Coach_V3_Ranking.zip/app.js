const workouts=[
["LUNDI","Calisthenics Upper",["Tractions 4×4–8","Pompes sur poignées 3×8–15","Rowing haltère 3×10–15","Pike push-ups 3×6–12","L-sit 4×10–30s","Planche 3×30–60s"]],
["MARDI","Jambes + explosivité",["Sauts verticaux 4×4–5","Squats haltères 3×10–15","Bulgarian split squat 3×8–12","Soulevé de terre roumain 3×10–15","Sauts latéraux 3×5/côté","Planche latérale 3×30–45s"]],
["MERCREDI","Repos / natation",["Récupération"]],
["JEUDI","Force + calisthenics",["Tractions lestées légères 3×4–6","Pompes lestées légères 3×6–10","Rowing haltère 3×10–15","Shoulder press 3×8–12","Élévations latérales 2×12–15","Frog stand 4×10–30s","L-sit 3×10–30s"]],
["VENDREDI","Repos",["Récupération"]],
["SAMEDI","Full body athlétique",["Sauts verticaux 3×5","Tractions 3×4–8","Pompes explosives 3×4–6","Squats haltères 3×10–15","Fentes 2×10/jambe","Rowing haltère 3×10–15","Planche 3×30–60s"]],
["DIMANCHE","Repos",["Récupération"]]
];
const ranks=[
["BRONZE III",500],["BRONZE II",700],["BRONZE I",900],["ARGENT III",1200],["ARGENT II",1500],["ARGENT I",1800],
["OR III",2200],["OR II",2700],["OR I",3200],["PLATINE III",3800],["PLATINE II",4500],["PLATINE I",5200],
["DIAMANT III",6000],["DIAMANT II",7000],["DIAMANT I",8200],["MASTER",10000],["GRAND MASTER",12500]
];
let data=JSON.parse(localStorage.getItem("hybridV3")||'{"xp":0,"sessions":0,"sets":0,"history":[],"perf":{}}');
let current=0, ex=0, timer=90, interval=null;
function save(){localStorage.setItem("hybridV3",JSON.stringify(data));render()}
function getRank(){let idx=0;for(let i=0;i<ranks.length;i++){if(data.xp>=ranks[i][1])idx=i;else break}return idx}
function render(){
 let idx=getRank(), r=ranks[idx], next=ranks[idx+1], base=r[1], cap=next?next[1]:base+2500, pct=next?Math.min(100,(data.xp-base)/(cap-base)*100):100;
 rankName.textContent=r[0];rankIcon.textContent=r[0][0];xpText.textContent=`${data.xp} / ${next?next[1]:"MAX"} XP`;nextRank.textContent=next?`Prochain rang : ${next[0]}`:"Rang maximum";xpBar.style.width=pct+"%";
 sessions.textContent=data.sessions;sets.textContent=data.sets;xpTotal.textContent=data.xp;
 week.innerHTML=workouts.map((w,i)=>`<div class="day"><small>${w[0]}</small><b>${w[1]}</b><span class="${data.history.includes(i)?"done":""}">${data.history.includes(i)?"✓ Terminée":w[2].length+" exercices"}</span></div>`).join("");
 rankList.innerHTML=ranks.map((x,i)=>`<div class="rankrow ${i===idx?"current":""}"><div class="mini">${x[0][0]}</div><div><b>${x[0]}</b><br><small>${x[1]} XP requis</small></div></div>`).join("");
 perf.innerHTML=Object.keys(data.perf).length?Object.entries(data.perf).map(([k,v])=>`<p><b>${k}</b> — ${v}</p>`).join(""):"Aucune performance enregistrée.";
}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.page").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.tab).classList.add("active")});
startBtn.onclick=()=>{let i=new Date().getDay();i=i===0?6:i-1;current=i;ex=0;sessionDay.textContent=workouts[i][0];sessionTitle.textContent=workouts[i][1];showEx();modal.classList.remove("hidden")};
function showEx(){let w=workouts[current], name=w[2][ex];exercise.innerHTML=`<div class="exerciseName">${name}</div><div class="exerciseMeta">Exercice ${ex+1} / ${w[2].length}</div><div class="exerciseNote">Priorité à la technique. Valide une série seulement si elle est propre et contrôlée.</div>`}
done.onclick=()=>{data.sets++;data.xp+=10;if(ex<workouts[current][2].length-1){ex++;startTimer()}else{data.sessions++;data.xp+=100;if(!data.history.includes(current))data.history.push(current);modal.classList.add("hidden");clearInterval(interval)}save();showEx()};
prev.onclick=()=>{if(ex>0){ex--;showEx()}};
close.onclick=()=>modal.classList.add("hidden");skip.onclick=()=>{timer=0;timerEl()};
const timerEl=()=>{timerElEl.textContent=timer};
function startTimer(){clearInterval(interval);timer=90;timerElEl.textContent=timer;interval=setInterval(()=>{timer--;timerElEl.textContent=timer;if(timer<=0)clearInterval(interval)},1000)}
const timerElEl=document.getElementById("timer");
reset.onclick=()=>{if(confirm("Réinitialiser toutes les données ?")){localStorage.removeItem("hybridV3");location.reload()}};
render();