HYBRID COACH V3 — RANKING
1. Héberge ce dossier sur un site HTTPS.
2. Sur Android/Chrome : menu ⋮ > Installer l'application / Ajouter à l'écran d'accueil.
3. Les données de progression sont stockées localement dans le navigateur.
